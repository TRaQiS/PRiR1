package com.company;

import java.util.Random;
public class Tramwaj extends Thread {
    static int PERON = 1;
    static int START = 2;
    static int JAZDA = 3;
    static int KONIEC_JAZDY = 4;
    static int WYKOLEJENIE = 5;
    static int TANKUJ = 1000;
    static int DOPUSZCZALNA_PREDKOSC_STABILNOSCI = 90;
    static int OGRANICZENIE_PREDKOSCI = 70;
    
    int numer;
    int predkosc;
    int stan;
    Stacja p;
    Random rand;

    public Tramwaj(int numer, int predkosc, Stacja p) {
        this.numer = numer;
        this.predkosc = predkosc;
        this.stan = JAZDA;
        this.p = p;
        rand = new Random();
    }

    public void run() {
        while (true) {
            if (stan == PERON) {
                if (rand.nextInt(2) == 1) {
                    stan = START;
                    predkosc = TANKUJ;
                    System.out.println("Prosba o pozwolenie na odjazd, tramwaju o numerze " + numer);
                    stan = p.start(numer);
                } else {
                    System.out.println("Tramwaj o numerze "+ numer + " oczekuje na zielone swiatlo");
                }
            } else if (stan == START) {
                System.out.println("Tramwaj o numerze " + numer + "odjezdza ze stacji");
                stan = JAZDA;
            } else if (stan == JAZDA) {
                predkosc = rand.nextInt(150);
                if (predkosc >= DOPUSZCZALNA_PREDKOSC_STABILNOSCI) {
                    stan = KONIEC_JAZDY;
                } else if (predkosc >= OGRANICZENIE_PREDKOSCI) {
                    System.out.println("Mandat dla motorniczego tramwaju: " + numer + " o wysokosci 6500 PLN. Wystawil: Karol Krawczyk");
                } else try {
                    sleep(rand.nextInt(1000));
                } catch (Exception e) {
                }
            } else if (stan == KONIEC_JAZDY) {
                System.out.println("Tramwaj nr " + numer + " kontaktuje sie z sygnalista z prosba o wjazd na stacje");
                System.out.println("Tramwaj nr " + numer + " wjezdza na stacje");
                stan = p.wjedz();

                if (stan == KONIEC_JAZDY) {
                    predkosc = rand.nextInt(150);
                    if (predkosc >= DOPUSZCZALNA_PREDKOSC_STABILNOSCI) stan = WYKOLEJENIE;
                }
            } else if (stan == WYKOLEJENIE) {
                System.out.println("WYKOLEJENIE tramwaju o numerze " + numer);
                p.zmniejsz();
            }
        }
    }
}