package com.company;

public class Symulator_Wroclawia {
    static int ilosc_tramwajow=100;
    static int ilosc_torow=100;
    static Stacja stacja;
    public Symulator_Wroclawia(){
    }
    public static void main(String[] args) {
        stacja =new Stacja(ilosc_torow, ilosc_tramwajow);
        for(int i=0;i<ilosc_tramwajow;i++)
            new Tramwaj(i,2000, stacja).start();
    }
}