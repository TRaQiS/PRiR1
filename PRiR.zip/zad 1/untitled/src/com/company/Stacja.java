package com.company;

public class Stacja {
    static int PERON = 1;
    static int START = 2;
    static int KONIEC_JAZDY = 4;
    int ilosc_torow;
    int ilosc_zajetych_torow;
    int ilosc_tramwajow;
    public Stacja(int ilosc_torow, int ilosc_pociagow){
        this.ilosc_torow =ilosc_torow;
        this.ilosc_tramwajow =ilosc_pociagow;
        this.ilosc_zajetych_torow =0;
    }
    synchronized int start(int numer){
        ilosc_zajetych_torow--;
        System.out.println("Pozwolenie na odjazd tramwaju numer:  "+numer);
        return START;
    }
    synchronized int wjedz(){
        try{
            Thread.currentThread().sleep(1000);
        }
        catch(Exception ie){
        }
        if(ilosc_zajetych_torow < ilosc_torow){
            ilosc_zajetych_torow++;
            System.out.println("Pozwolenie wjazdu na stacje "+ ilosc_zajetych_torow);
            return PERON;
        }
        else
        {return KONIEC_JAZDY;}
    }
    synchronized void zmniejsz(){
        ilosc_tramwajow--;
        if(ilosc_tramwajow == ilosc_torow) System.out.println("ILOSC TRAMWAJOW JEST TAKA SAMA JAK ILOSC TOROW______________");
    }
}
