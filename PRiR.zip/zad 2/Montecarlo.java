import java.util.Random;

public class Montecarlo extends Thread{

   double promien;
   double ilosc_punktow, finalne_pole;
   double bok_kwadratu = promien * 2;
   int punkty_nalezace_do_okregu = 0;
   int start, end;

   public Montecarlo(double promien, double ilosc_punktow, int start, int end) {
      this.promien = promien;
      this.ilosc_punktow = ilosc_punktow;
      this.start = start;
      this.end = end;
   }

   boolean czyOkrag(double x, double y, double okragX, double okragY, double promien) {
      return Math.sqrt(Math.pow((x - okragX),2) + Math.pow((y - okragY),2)) <= promien;
   }

   double get_pkt() {
      return punkty_nalezace_do_okregu;
   }
   
   void pole() {
      double bok_kwadratu = promien * 2;
      double okragX = promien, okragY = promien;
      double x, y;
      
      Random random = new Random();
      for (int i = start; i < end ; i++) {
         x =  random.nextDouble() * bok_kwadratu;
         y =  random.nextDouble() * bok_kwadratu;
         if (czyOkrag(x, y, okragX, okragY, promien)) {
            punkty_nalezace_do_okregu += 1;
         }
      }
   }

   public synchronized void run() {
      pole();
   }
   
   public static void main(String[] args) {
      boolean kontrolka = true;
      double finalne_punkty = 0;

      int ilosc_punktow = 1000000000;
      double promien = 1;
      double bok_kwadratu = promien * 2;
      Montecarlo montecarlo1 = new Montecarlo(promien, ilosc_punktow, 0, (int)(ilosc_punktow/4));
      Montecarlo montecarlo2 = new Montecarlo(promien, ilosc_punktow, (int)(ilosc_punktow/4), (int)(ilosc_punktow/2));
      Montecarlo montecarlo3 = new Montecarlo(promien, ilosc_punktow, (int)(ilosc_punktow/2), (int)(ilosc_punktow/4*3));
      Montecarlo montecarlo4 = new Montecarlo(promien, ilosc_punktow, (int)(ilosc_punktow/4*3), (int)(ilosc_punktow));
      montecarlo1.start();
      montecarlo2.start();
      montecarlo3.start();
      montecarlo4.start();

      while(kontrolka) {
         if(!montecarlo1.isAlive() && !montecarlo2.isAlive() && !montecarlo3.isAlive() && !montecarlo4.isAlive()) {
            finalne_punkty += montecarlo1.get_pkt();
            finalne_punkty += montecarlo2.get_pkt();
            finalne_punkty += montecarlo3.get_pkt();
            finalne_punkty += montecarlo4.get_pkt();
            System.out.println(finalne_punkty / ilosc_punktow * Math.pow(bok_kwadratu,2));
            kontrolka = false;
         }
      }
   }
}