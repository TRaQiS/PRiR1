import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.ImageIO;
import javax.swing.JFrame;


public class GrayScale extends Thread {
   BufferedImage image;
   int pixelStartY;
   int pixelEndY;
   int pixelStartX;
   int pixelEndX;

   public GrayScale(BufferedImage image, int pixelStartY, int pixelEndY, int pixelStartX, int pixelEndX) throws IOException {
      this.image = image;
      this.pixelStartY = pixelStartY;
      this.pixelEndY = pixelEndY;
      this.pixelStartX = pixelStartX;
      this.pixelEndX = pixelEndX;
   }

   public void run() {
      try {
         for (int i = pixelStartY; i < pixelEndY - 1; i++) {
               for (int j = pixelStartX; j < pixelEndX - 1; j++) {

                  //odczyt składowych koloru RGB
                  Color c = new Color(image.getRGB(j, i));
                  int red = (int) (c.getRed());
                  int green = (int) (c.getGreen());
                  int blue = (int) (c.getBlue());

                  int final_red, final_green, final_blue;

                  final_red = 255 - red;
                  final_green = 255 - green;
                  final_blue = 255 - blue;
                  Color newColor = new Color(final_red, final_green, final_blue);
                  image.setRGB(j, i, newColor.getRGB());
               }
         }
         File ouptut = new File("grayscale.jpg");
         ImageIO.write(image, "jpg", ouptut);
      } catch (Exception e) {

      }
   }

   static public void main(String args[]) throws Exception {
      BufferedImage image;
      int width;
      int height;
      File input = new File("kojot.jpg");
      image = ImageIO.read(input);
      width = image.getWidth();
      height = image.getHeight();

      GrayScale neg = new GrayScale(image, 0, height/2+1, 0, width);
      GrayScale neg2 = new GrayScale(image, height/2, height, 0, width);
      neg.start();
      neg2.start();
   }
}